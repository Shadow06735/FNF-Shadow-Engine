Put your custom character icons here!
Icons don't need to start with "icon-", but it'll be read anyways.
The image resolution must have a minimal of 300x150